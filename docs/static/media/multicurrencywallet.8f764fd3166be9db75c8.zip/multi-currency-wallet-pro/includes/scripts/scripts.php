<?php
/**
 * Scripts
 * 
 * @package Envato API Functions
 */

/**
 * Admin Scripts
 */
require MCWALLET_PATH . 'includes/scripts/admin-scripts.php';

/**
 * Front Scripts
 */
require MCWALLET_PATH . 'includes/scripts/front-scripts.php';

/**
 * Login Scripts
 */
require MCWALLET_PATH . 'includes/scripts/login-scripts.php';
