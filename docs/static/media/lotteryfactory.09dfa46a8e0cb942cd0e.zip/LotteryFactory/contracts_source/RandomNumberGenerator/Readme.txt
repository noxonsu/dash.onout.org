Генератор случайных чисел для лотереи
https://bscscan.com/address/0x8c6375aab6e5b26a30bf241ebbf29ad6e6c503c2#code
Contract Name:
RandomNumberGenerator
Compiler Version
v0.8.4+commit.c7e474f2
Optimization Enabled:
Yes with 99999 runs
Other Settings:
default evmVersion, MIT license

Constructor Arguments (ABI-Encoded and is the last bytes of the Contract Creation Code above)
000000000000000000000000747973a5a2a4ae1d3a8fdf5479f1514f65db9c31000000000000000000000000404460c6a5ede2d891e8297795264fde62adbb75

-----Decoded View---------------
Arg [0] : _vrfCoordinator (address): 0x747973a5a2a4ae1d3a8fdf5479f1514f65db9c31
Arg [1] : _linkToken (address): 0x404460c6a5ede2d891e8297795264fde62adbb75



testnet

vfr = 0xba3824b49f5d0c67dccc64d35fe92604fd086325
token = 0x692f6efdfdebc7be1c24f02badf2ea877a6afdae

constructor testnet
0xba3824b49f5d0c67dccc64d35fe92604fd086325, 0x692f6efdfdebc7be1c24f02badf2ea877a6afdae

https://testnet.bscscan.com/address/0x61eeac8b9db0df4e5e3ccc651f16fffc6c1d4456#code

0x61eeac8b9db0df4e5e3ccc651f16fffc6c1d4456


установить фии
https://bscscan.com/tx/0xdda9df026eeface1667e4702371f5f2a70609273c446db17b6ca6cb86079a850
установить хеш setKeyHash
https://bscscan.com/tx/0x2e5f1f7c9ad8bfbb17359bfd92232fd353ee57e35b5beea037c766f5b02bc9a6
установить адрес контракта лотереи
https://bscscan.com/tx/0x7fe4ace6cbf9de3581d06ef9c8ec4805dd85c27160ee24015f4f25462c079f3c