interface Window {
  Web3Modal: any
  Web3: any
  BigNumber: any
  evmChains: any
}
