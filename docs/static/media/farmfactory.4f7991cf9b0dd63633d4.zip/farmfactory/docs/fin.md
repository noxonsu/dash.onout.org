## payouts
| date   | balance | status |
|--------|-----------------|------------|
| 15.10.2021 |  2827   | on noxon's bannk |
| 15.11.2021 |  2087 (+ 2827 не потратили) = $4 914  | on noxon's bannk |
| 15.12.2021 |  2974 (+ 350к руб) = $2974 + 350к налом  |  |
| 07.01.2022 |  0  | lotte | 
| 15.01.2022 |  1649  | bank |


инструкция: смотрим когда была последняя payouts, добавляем income+other income который был с тех пор (кастом джоб не считаем, там индивидуально), добавляем в "minus" расходку. далее смотрим когда был последний payout, и считаем прибыль с той даты, добавляем новую строку в payouts и в статусе пишем у когдо бабки, после трат пишем wasted. 

## income:
  
| date   | amount | 
|--------|-----------------------------|
| 26 jan | -257$ in 0.188252076 ETH (deploy to mainnet)     | 
| 4 feb | 100$ (add bsc)  | 
| 15 feb | 94$ (envato 01.2021 earnings)  | 
| 14 mar | 200$ (Ticket #T000065 from Sam Language: en)  | 
| 15 mar | 743$ (envato 02.2021 earnings)  | 
| 2 apr mar | -880$ gorinich party  | 
| 15 jun | 2004$ (envato 02.2021-05.2021 earnings)  | 
| 15 jul | 1000$ (1500 (envato 06.2021 earnings) - $500 freelancers) | 
| 15 oct | 2350$ (2500 (envato 07,08,09.2021 earnings) - 150 freelancers) | 
| 15 nov | 2087$ (2147.94$ envato 10.2021 earnings - 60 freelancers) | 
| 15 dec 21 | 2974$ (3034$ envato 11.2021 earnings - 60 freelancers) | 
| 15 01 22 | 1649$ (1769$ envato - 120 freelancers ) | 

### other income (only sales, not custom job etc)..
| date   | amount | 
|--------|-----------------------------|
| 21 mar | 300$ (#T000071) |
| 13 apr | 299$ (#T000084) |
| ------ | ---- |
| 20 jun | 400$ (@rekl...) |
| 29 jun | 499$ (@bitcoinau...) |
| 31 aug | 477$ (etheum by) |
| 29 oct 21 | 490$ #T000201  |

## minus
| date   | amount | 
|--------|-----------------------------|
| 28.07.21 |  -$330 (ion)   |
| 28.07.21 |  -$160 (dis)   |
| 08.09.21 |  -$160 (dis)   |
| 15.10.21 |  -$60 (shendel tokenprice shortcode)   |
| 15.12.21 |  -$60 (vit walletconnect fix)   |
| 15.01.22 |  -$120 (vit support & fixes)   |


