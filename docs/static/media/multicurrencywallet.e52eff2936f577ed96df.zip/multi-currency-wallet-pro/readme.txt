Warning! This is free version of the plugin https://wordpress.org/plugins/multi-currency-wallet/

To activate premium features buy full version here https://codecanyon.net/item/multicurrency-crypto-wallet-and-exchange-widgets-for-wordpress/23532064 

=== Multi Currency Wallet ===
Contributors: noxonsu, burdianov
Tags: adress generation, bitcoin, blockchain, crypto, cryptocurrency, eos, ethereum, exchange, shortcode, wallet, widget
Requires at least: 5.0
Tested up to: 5.5
Stable tag: 1.0.2
Requires PHP: 5.6
License: GNU General Public License version 3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Simplest Multi-currency wallet for WordPress.
 
== Description ==

Simplest Multi-currency wallet for WordPress. Check premium version https://codecanyon.net/item/multicurrency-crypto-wallet-and-exchange-widgets-for-wordpress/23532064

We use this 3rd party services:
https://etherscan.io/ - free public blockchain explorer. they provide information for user balances (Ethereum cryptoccurrency and ER20 assets);
https://infura.io/  - (free 100,000 Requests/Day) ethereum endoint to broadcast transactions.
https://www.blockchain.com/btc, https://api.blockcypher.com/v1/btc/main, https://live.blockcypher.com/ - bitcoin explorers 
https://ghostscan.io - GHOST blockchain explorer
https://explore.next.exchange - NEXT blockchain explorer
https://horizon.stellar.org - STELLAR blockchain exploreer
https://api.blocktrail.com/v1/BTC - Bitcoin mining fees data 
https://api.bitcore.io/api/BTC/mainnet - free bitcoin endpoint where we send a transactions for broadcatst to the bitcoin network. Otherwise user must install own bitcoin node.
https://next.swaponline.io/mainnet - NEXT blockchain node endpoint
https://noxon.wpmix.net/currsAll.php - free cryptocurrency price feed


== Usage ==

Activate plugin, go to MCW options and enable "Use Multi Currency Wallet template as home page."

== Frequently Asked Questions ==

= Can i add my own token? =

Yes, you can!.

== Screenshots ==

1. https://growup.wpmix.net/swap-docs/screenshots/admin-1.jpg
2. https://growup.wpmix.net/swap-docs/screenshots/admin-2.jpg

== Changelog ==

= 1.0.0 =
* Release

