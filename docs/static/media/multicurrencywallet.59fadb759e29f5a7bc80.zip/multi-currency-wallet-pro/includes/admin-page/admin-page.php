<?php
/**
 * Admin Page
 * 
 * @package Multi Currency Wallet
 */

/**
 * Main Admin Page
 */
require MCWALLET_PATH . 'includes/admin-page/admin-page-main.php';

/**
 * Add Design page to submenu
 */
require MCWALLET_PATH . 'includes/admin-page/admin-page-design.php';

/**
 * Admin Page Design
 */
require MCWALLET_PATH . 'includes/admin-page/admin-page-help.php';
