(this["webpackJsonppancake-frontend"]=this["webpackJsonppancake-frontend"]||[]).push([[7],{648:function(n,p){}}]);
//# sourceMappingURL=7.chunk.js.map