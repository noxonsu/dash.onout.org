<div id="v-app">
    <create-n-f-t-and-post/>
</div>