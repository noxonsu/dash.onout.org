self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "6d1c6975fa3836f055b097bd032def41",
    "url": "/index.html"
  },
  {
    "revision": "2d28ca8cda468e0b6f46",
    "url": "/static/css/3.chunk.css"
  },
  {
    "revision": "209fcd4072f9caa78372",
    "url": "/static/css/main.chunk.css"
  },
  {
    "revision": "78c78f76dc1b80f9c7bf",
    "url": "/static/js/0.chunk.js"
  },
  {
    "revision": "2d28ca8cda468e0b6f46",
    "url": "/static/js/3.chunk.js"
  },
  {
    "revision": "27c632e81b7253158c2168642b5522c4",
    "url": "/static/js/3.chunk.js.LICENSE.txt"
  },
  {
    "revision": "5ca284b82d8c9c74b4e3",
    "url": "/static/js/4.chunk.js"
  },
  {
    "revision": "3822e7bee4610088ad0f",
    "url": "/static/js/5.chunk.js"
  },
  {
    "revision": "086ac0f260c0d88cf399717695349565",
    "url": "/static/js/5.chunk.js.LICENSE.txt"
  },
  {
    "revision": "12242cc669d398dceb74",
    "url": "/static/js/6.chunk.js"
  },
  {
    "revision": "c207adeae3afe978bb10",
    "url": "/static/js/7.chunk.js"
  },
  {
    "revision": "209fcd4072f9caa78372",
    "url": "/static/js/main.chunk.js"
  },
  {
    "revision": "6f8d5349da2cac634879",
    "url": "/static/js/runtime-main.js"
  },
  {
    "revision": "661569afe57a38e1529a775a465da20b",
    "url": "/static/media/Inter-Black.661569af.woff2"
  },
  {
    "revision": "d0b121f3a9d3d88afdfd6902d31ee9a0",
    "url": "/static/media/Inter-Black.d0b121f3.woff"
  },
  {
    "revision": "a3cc36c89047d530522fc999a22cce54",
    "url": "/static/media/Inter-BlackItalic.a3cc36c8.woff2"
  },
  {
    "revision": "e3329b2b90e1f9bcafd4a36604215dc1",
    "url": "/static/media/Inter-BlackItalic.e3329b2b.woff"
  },
  {
    "revision": "444a7284663a3bc886683eb81450b294",
    "url": "/static/media/Inter-Bold.444a7284.woff2"
  },
  {
    "revision": "99a0d9a7e4c99c17bfdd94a22a5cf94e",
    "url": "/static/media/Inter-Bold.99a0d9a7.woff"
  },
  {
    "revision": "3aa31f7356ea9db132b3b2bd8a65df44",
    "url": "/static/media/Inter-BoldItalic.3aa31f73.woff"
  },
  {
    "revision": "96284e2a02af46d9ffa2d189eaad5483",
    "url": "/static/media/Inter-BoldItalic.96284e2a.woff2"
  },
  {
    "revision": "37da9eecf61ebced804b266b14eef98e",
    "url": "/static/media/Inter-ExtraBold.37da9eec.woff2"
  },
  {
    "revision": "ab70688a1c9d6525584b123575f6c0a5",
    "url": "/static/media/Inter-ExtraBold.ab70688a.woff"
  },
  {
    "revision": "728a4c7df3ed1b2bc077010063f9ef1c",
    "url": "/static/media/Inter-ExtraBoldItalic.728a4c7d.woff"
  },
  {
    "revision": "fcc7d60ef790b43eb520fdc5c7348799",
    "url": "/static/media/Inter-ExtraBoldItalic.fcc7d60e.woff2"
  },
  {
    "revision": "b3b2ed6a20c538e9c809f4df5c04ac2a",
    "url": "/static/media/Inter-ExtraLight.b3b2ed6a.woff2"
  },
  {
    "revision": "dd19efda9c6e88ad83a5b052915899f7",
    "url": "/static/media/Inter-ExtraLight.dd19efda.woff"
  },
  {
    "revision": "079cd1e71cd4f73bef86f72deced6d03",
    "url": "/static/media/Inter-ExtraLightItalic.079cd1e7.woff2"
  },
  {
    "revision": "a6566ae6fa3c58b48f888d7c9c234d52",
    "url": "/static/media/Inter-ExtraLightItalic.a6566ae6.woff"
  },
  {
    "revision": "f137a90d649b6ab032563856df323f40",
    "url": "/static/media/Inter-Italic.f137a90d.woff"
  },
  {
    "revision": "fd26ff23f831db9ae85a805386529385",
    "url": "/static/media/Inter-Italic.fd26ff23.woff2"
  },
  {
    "revision": "5d3776eb78374b0ebbce639adadf73d1",
    "url": "/static/media/Inter-Light.5d3776eb.woff"
  },
  {
    "revision": "780dd2adb71f18d7a357ab7f65e881d6",
    "url": "/static/media/Inter-Light.780dd2ad.woff2"
  },
  {
    "revision": "d0fa7cbcf9ca5edb6ebe41fd8d49e1fb",
    "url": "/static/media/Inter-LightItalic.d0fa7cbc.woff"
  },
  {
    "revision": "df29c53403b2e13dc56df3e291c32f09",
    "url": "/static/media/Inter-LightItalic.df29c534.woff2"
  },
  {
    "revision": "75db5319e7e87c587019a5df08d7272c",
    "url": "/static/media/Inter-Medium.75db5319.woff2"
  },
  {
    "revision": "c0638bea87a05fdfa2bb3bba2efe54e4",
    "url": "/static/media/Inter-Medium.c0638bea.woff"
  },
  {
    "revision": "a1b588627dd12c556a7e3cd81e400ecf",
    "url": "/static/media/Inter-MediumItalic.a1b58862.woff"
  },
  {
    "revision": "f1e11535e56c67698e263673f625103e",
    "url": "/static/media/Inter-MediumItalic.f1e11535.woff2"
  },
  {
    "revision": "3ac83020fe53b617b79b5e2ad66764af",
    "url": "/static/media/Inter-Regular.3ac83020.woff"
  },
  {
    "revision": "dc131113894217b5031000575d9de002",
    "url": "/static/media/Inter-Regular.dc131113.woff2"
  },
  {
    "revision": "007ad31a53f4ab3f58ee74f2308482ce",
    "url": "/static/media/Inter-SemiBold.007ad31a.woff2"
  },
  {
    "revision": "66a68ffab2bf40553e847e8f025f75be",
    "url": "/static/media/Inter-SemiBold.66a68ffa.woff"
  },
  {
    "revision": "3031b683bafcd9ded070c00d784f4626",
    "url": "/static/media/Inter-SemiBoldItalic.3031b683.woff2"
  },
  {
    "revision": "6cd13dbd150ac0c7f337a2939a3d50a8",
    "url": "/static/media/Inter-SemiBoldItalic.6cd13dbd.woff"
  },
  {
    "revision": "b068b7189120a6626e3cfe2a8b917d0f",
    "url": "/static/media/Inter-Thin.b068b718.woff"
  },
  {
    "revision": "d52e5e38715502616522eb3e9963b69b",
    "url": "/static/media/Inter-Thin.d52e5e38.woff2"
  },
  {
    "revision": "97bec98832c92f799aeebf670b83ff6c",
    "url": "/static/media/Inter-ThinItalic.97bec988.woff"
  },
  {
    "revision": "a9780071b7f498c1523602910a5ef242",
    "url": "/static/media/Inter-ThinItalic.a9780071.woff2"
  },
  {
    "revision": "1f7ca6383ea7c74a7f5ddd76c3d3cef2",
    "url": "/static/media/Inter-italic.var.1f7ca638.woff2"
  },
  {
    "revision": "66c6e40883646a7ad993108b2ce2da32",
    "url": "/static/media/Inter-roman.var.66c6e408.woff2"
  },
  {
    "revision": "8dd26c3dd0125fb16ce19b8f5e8273fb",
    "url": "/static/media/Inter.var.8dd26c3d.woff2"
  },
  {
    "revision": "fa428345f1550e1de5067f59cfc31e23",
    "url": "/static/media/arbitrum.fa428345.png"
  },
  {
    "revision": "cd061363bbf9cd7a26cb09b642dcaf63",
    "url": "/static/media/arrow-down-blue.cd061363.svg"
  },
  {
    "revision": "c0dedd2f2ed0c4d07d7ca75af3f0a65f",
    "url": "/static/media/arrow-down-grey.c0dedd2f.svg"
  },
  {
    "revision": "337ad716bd89163e2a9c3495b7e0f029",
    "url": "/static/media/arrow-right-white.337ad716.png"
  },
  {
    "revision": "d285b6cf22b4f1552bb4009333462632",
    "url": "/static/media/arrow-right.d285b6cf.svg"
  },
  {
    "revision": "e7a52317c05b6ec3392085d52123968f",
    "url": "/static/media/aurora.e7a52317.svg"
  },
  {
    "revision": "2565884a03843bf5f37bf4a806402acf",
    "url": "/static/media/avax.2565884a.png"
  },
  {
    "revision": "904b44c2b22eb2d49f618396e6f2db1a",
    "url": "/static/media/blue-loader.904b44c2.svg"
  },
  {
    "revision": "162aaf57c64bd732a87c2d553a12f165",
    "url": "/static/media/bnb.162aaf57.png"
  },
  {
    "revision": "ed2a1dad16cb9a4b9afd788ddaae7290",
    "url": "/static/media/circle-grey.ed2a1dad.svg"
  },
  {
    "revision": "2d975615c4c409c3b6b00e8ae7c5767a",
    "url": "/static/media/circle.2d975615.svg"
  },
  {
    "revision": "62578f5994645a1825d4829e2c4394b0",
    "url": "/static/media/coinbaseWalletIcon.62578f59.svg"
  },
  {
    "revision": "f578d9cdc830bae843b72c87b78b4b1c",
    "url": "/static/media/cro.f578d9cd.svg"
  },
  {
    "revision": "78feb91bfda2ddce6bcfdcbab050995b",
    "url": "/static/media/de.78feb91b.svg"
  },
  {
    "revision": "b20914ec5482543a0b1b2c6d5509ab96",
    "url": "/static/media/dropdown-blue.b20914ec.svg"
  },
  {
    "revision": "7d32d2fa19d17d6ab9f0e0067bebaf96",
    "url": "/static/media/dropdown.7d32d2fa.svg"
  },
  {
    "revision": "b96d70e10dd30a64a0d122603577c8ae",
    "url": "/static/media/dropup-blue.b96d70e1.svg"
  },
  {
    "revision": "8886b28b10e3ec0756a9935a216d5bba",
    "url": "/static/media/en.8886b28b.svg"
  },
  {
    "revision": "426a1551c98dbbe2a847dd8fd0e2eb5b",
    "url": "/static/media/es.426a1551.svg"
  },
  {
    "revision": "86b356aa4636232f3e200c65d2a8b6b4",
    "url": "/static/media/eth.86b356aa.png"
  },
  {
    "revision": "3af63018071dc72f01ff1880304ea6ec",
    "url": "/static/media/ftm.3af63018.svg"
  },
  {
    "revision": "65ec57528b9f6dbfbcf5f7cdde0603da",
    "url": "/static/media/fuse.65ec5752.svg"
  },
  {
    "revision": "cb9b3252a26b080c4964baeb2b7ff53c",
    "url": "/static/media/glmr.cb9b3252.png"
  },
  {
    "revision": "0d242628b316a0661456f0126257d3d1",
    "url": "/static/media/ht.0d242628.svg"
  },
  {
    "revision": "1d72a5dec3acd073763570e3e5fdf784",
    "url": "/static/media/it.1d72a5de.svg"
  },
  {
    "revision": "519847287bb66fbec84a8233cf5597d5",
    "url": "/static/media/iw.51984728.svg"
  },
  {
    "revision": "50c67f3cdd04281013ef95e92fc7244e",
    "url": "/static/media/link.50c67f3c.svg"
  },
  {
    "revision": "674400972753804891ec372652944539",
    "url": "/static/media/magnifying-glass.67440097.svg"
  },
  {
    "revision": "1ee4a1ab4dd95100e8d21e67acf53849",
    "url": "/static/media/matic.1ee4a1ab.png"
  },
  {
    "revision": "4f2c4440e19ed9428d0caae5d9840df6",
    "url": "/static/media/menu.4f2c4440.svg"
  },
  {
    "revision": "023762b6aec2a2249b8fdfb638f00ef3",
    "url": "/static/media/metamask.023762b6.png"
  },
  {
    "revision": "7b05fcf4c86e0e00c1053d6facbac3c8",
    "url": "/static/media/optimisticEth.7b05fcf4.svg"
  },
  {
    "revision": "e8021e51723d455b2f9fa2446808d2a3",
    "url": "/static/media/plus-blue.e8021e51.svg"
  },
  {
    "revision": "d8e0be7d6efb0b53c37eb75e44b35bda",
    "url": "/static/media/plus-grey.d8e0be7d.svg"
  },
  {
    "revision": "b234b2bfa0417c7e8711c3a8d17afeec",
    "url": "/static/media/portisIcon.b234b2bf.png"
  },
  {
    "revision": "1ae4d9f4653371789d98b85139933d27",
    "url": "/static/media/question-mark.1ae4d9f4.svg"
  },
  {
    "revision": "a46e8bc1a36444be83a85007353d692f",
    "url": "/static/media/question.a46e8bc1.svg"
  },
  {
    "revision": "3f61edb2c675ef535b0847ef14556579",
    "url": "/static/media/rbtc.3f61edb2.png"
  },
  {
    "revision": "ab61f31edf4ad95b5ae00aff3be99197",
    "url": "/static/media/ru.ab61f31e.svg"
  },
  {
    "revision": "be00fc4a29d03016e78b28c9943e3f51",
    "url": "/static/media/spinner.be00fc4a.svg"
  },
  {
    "revision": "db76ba27ecaa7ced92a58b1ae94d09f4",
    "url": "/static/media/tomo.db76ba27.svg"
  },
  {
    "revision": "edcc1ab5dde5cb3d5cf134c4aade641b",
    "url": "/static/media/trustWallet.edcc1ab5.png"
  },
  {
    "revision": "8215855c185176eb79446ce8cc1f3998",
    "url": "/static/media/walletConnectIcon.8215855c.svg"
  },
  {
    "revision": "5b8e218668bfea1d44b887bd042f6a52",
    "url": "/static/media/x.5b8e2186.svg"
  },
  {
    "revision": "573f0f5f8086daf29bbfeea736b3ba39",
    "url": "/static/media/xdai.573f0f5f.png"
  },
  {
    "revision": "5c573ebe5273a73856cae1ef8b8dd88c",
    "url": "/static/media/zh.5c573ebe.svg"
  }
]);