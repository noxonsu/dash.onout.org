<?php
/**
 * Admin Page Pro
 * 
 * @package Envato API Functions
 */

/**
 * Admin Page License
 */
require MCWALLET_PATH . 'pro/admin-page-license.php';
