Главный контракт лотереи
https://bscscan.com/address/0x5af6d33de2ccec94efb1bdf8f92bd58085432d2c#code
Contract Name:
PancakeSwapLottery
Compiler Version
v0.8.4+commit.c7e474f2
Optimization Enabled:
Yes with 99999 runs
Other Settings:
default evmVersion, MIT license

Constructor Arguments (ABI-Encoded and is the last bytes of the Contract Creation Code above)
0000000000000000000000000e09fabb73bd3ade0a17ecc321fd13a19e81ce820000000000000000000000008c6375aab6e5b26a30bf241ebbf29ad6e6c503c2

-----Decoded View---------------
Arg [0] : _cakeTokenAddress (address): 0x0e09fabb73bd3ade0a17ecc321fd13a19e81ce82
Arg [1] : _randomGeneratorAddress (address): 0x8c6375aab6e5b26a30bf241ebbf29ad6e6c503c2

-----Encoded View---------------
2 Constructor Arguments found :
Arg [0] : 0000000000000000000000000e09fabb73bd3ade0a17ecc321fd13a19e81ce82
Arg [1] : 0000000000000000000000008c6375aab6e5b26a30bf241ebbf29ad6e6c503c2


testnet constructor

token: 0x703f112bda4cc6cb9c5fb4b2e6140f6d8374f10b - weenus

0x703f112bda4cc6cb9c5fb4b2e6140f6d8374f10b

testnet - 5 minutes
https://testnet.bscscan.com/address/0xbb6e81ae73b8a09c964ecd361e36b573aa332cab#code
0xbb6e81ae73b8a09c964ecd361e36b573aa332cab


Start lottery tx
https://bscscan.com/tx/0x56ae29f6a75e9836081dac921e264a0a2e700bbb62524608c48190ec768a64d4
0	_endTime	uint256	1638057600
1	_priceTicketInCake	uint256	370000000000000000
2	_discountDivisor	uint256	2000
3	_rewardsBreakdown	uint256[6]	250
375
625
1250
2500
5000
4	_treasuryFee	uint256	2000

testnet example
https://testnet.bscscan.com/tx/0x1f2333e1938cf922729d832fd9c8c00dc06e972f5eddfe435f92b5bdc99656cb


Buy ticket 
https://bscscan.com/tx/0xe732c16c0555ba27dd16d1e09888223777b787cab6bb6e4a60c71b46007a697a
#	Name	Type	Data
0	_lotteryId	uint256	296
1	_ticketNumbers	uint32[]	1041340



matic testnet https://mumbai.polygonscan.com/address/0x6e9c98a8a481bf038ba7e1d669a0086547dd144e#code
0x6e9c98a8a481bf038ba7e1d669a0086547dd144e
token plasma 0x2d7882beDcbfDDce29Ba99965dd3cdF7fcB10A1e