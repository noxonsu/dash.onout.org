https://bscscan.com/address/0xfa390a2e7c3c3bc2f97fe63f11ef21bac455f121#code
Хранилище блоков (общее для всех)
Contract Name:
BlockhashStore
Compiler Version
v0.6.6+commit.6c089d02
Optimization Enabled:
Yes with 1000000 runs
Other Settings:
default evmVersion, MIT license

https://testnet.bscscan.com/address/0xd803c85e9db7c94c16bb1b104c1c2d68f221a6bd#code

testnet 0xd803c85e9db7c94c16bb1b104c1c2d68f221a6bd