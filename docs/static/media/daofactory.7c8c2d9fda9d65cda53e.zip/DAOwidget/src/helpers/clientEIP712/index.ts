import { Client } from "./clientEIP712";

const client = new Client();

export default client;
