https://bscscan.com/address/0x404460c6a5ede2d891e8297795264fde62adbb75#code
Link токен, для оплаты генератора случайных чисел (LinkLotteryToken)
Contract Name:
LinkLotteryToken
Compiler Version
v0.4.16+commit.d7661dd9
Optimization Enabled:
Yes with 200 runs
Other Settings:
default evmVersion, MIT license

testnet https://testnet.bscscan.com/address/0x692f6efdfdebc7be1c24f02badf2ea877a6afdae

0x692f6efdfdebc7be1c24f02badf2ea877a6afdae