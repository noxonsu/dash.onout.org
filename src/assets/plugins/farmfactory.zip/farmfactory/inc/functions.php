<?php
/**
 * Functions
 *
 * @package Farm Factory
 */

/**
 * Get default Infura ID
 */
function farmfactory_default_infura_id() {
	return '8043bb2cf99347b1bfadfb233c5325c0';
}
