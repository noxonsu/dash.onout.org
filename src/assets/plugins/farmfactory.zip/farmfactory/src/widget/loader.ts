const loader = (black?: boolean) => `<div class="farmfactory-loader${black ? ' black' : ''}"><div></div><div></div><div></div></div>`


export default loader
