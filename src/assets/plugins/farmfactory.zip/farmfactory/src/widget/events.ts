import EventAggregator from './EventAggregator'


const events = new EventAggregator()


export default events
